<?php
    require '../banco.php';

    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    $login = $_GET['login'];
    $senha = $_GET['senha'];

    $sql = "SELECT id,nome FROM `usuario` where `login`='".$login."' and `senha`='".$senha."' limit 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $usuarios = array();

        while($row = $result->fetch_assoc()) {
            $row['id'] = intval($row['id']);
            $usuarios[] = $row;		
        }
        header('Content-Type: application/json');
        echo  json_encode($usuarios, JSON_PRETTY_PRINT);
    } else {
        echo "1";
    }	
?>   




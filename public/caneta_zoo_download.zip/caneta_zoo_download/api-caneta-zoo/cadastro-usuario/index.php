<?php
    require '../banco.php';
    $data = json_decode(file_get_contents('php://input'), true);

    if(isset($data['nome']) && isset($data['login']) && isset($data['senha'])) {
        try {
            $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $nome = $data['nome'];
            $login = $data['login'];
            $senha = $data['senha'];

            $checkLoginStmt = $pdo->prepare("SELECT COUNT(*) FROM usuario WHERE login = :login");
            $checkLoginStmt->bindParam(':login', $login);
            $checkLoginStmt->execute();
            $loginExists = $checkLoginStmt->fetchColumn();

            if ($loginExists > 0) {
                $response = array('success' => false, 'message' => 'O login já está em uso.');
            } else {
                $sql = "INSERT INTO usuario(nome, login, senha) VALUES (:nome, :login, :senha)";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':login', $login);
                $stmt->bindParam(':senha', $senha);
                $stmt->execute();

                $response = array('success' => true, 'message' => 'Usuário cadastrado com sucesso');
            }

            echo json_encode($response);
        } catch (PDOException $e) {
            $response = array('success' => false, 'message' => 'Erro ao cadastrar usuário: ' . $e->getMessage());
            echo json_encode($response);
        }
    } else {
        $response = array('success' => false, 'message' => 'Todos os campos são obrigatórios');
        echo json_encode($response);
    }
?>

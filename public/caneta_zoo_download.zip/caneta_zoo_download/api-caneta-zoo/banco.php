<?php
$host = '127.0.0.1';
$port = '3306';
$dbname = 'caneta_zoo';
$username = 'root';
$password = 'q1w2e3';
?>

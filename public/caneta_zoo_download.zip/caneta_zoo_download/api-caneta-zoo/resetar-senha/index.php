<?php
    require '../banco.php';

    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    $login = $_GET['login'];
    $novaSenha = $_GET['novaSenha'];

    $sql = "SELECT id FROM usuario WHERE login = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $sqlUpdate = "UPDATE usuario SET senha = ? WHERE login = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->bind_param("ss", $novaSenha, $login);
        $stmtUpdate->execute();

        if ($stmtUpdate->affected_rows > 0) {
            echo "Senha atualizada com sucesso.";
        } else {
            echo "Erro ao atualizar a senha.";
        }
    } else {
        echo "Usuário não encontrado.";
    }
    
    $stmt->close();
    $stmtUpdate->close();
    $conn->close();
?>
